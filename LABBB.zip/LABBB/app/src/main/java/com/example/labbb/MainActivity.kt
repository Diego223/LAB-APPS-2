package com.example.fitnessapp

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import org.w3c.dom.Text
class MainActivity : AppCompatActivity() {

    var cont: Int = 0;
    var menos: Int = 0;


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }


    //método para las vuetlas

    fun ContadorVueltas(view: View) {
        if (cont != 20){
            cont++;
            vueltas.text = cont.toString()
        }

        //Toasts para los objetivos
        vuelta.setOnLongClickListener(){
            if (cont <= 10){
                menos = 10 - cont
                Toast.makeText(this, "Faltan " + menos.toString() + " vueltas siguiente objetivo.", Toast.LENGTH_SHORT).show()
            }

            if (cont > 10){
                menos = 20 - cont
                Toast.makeText(this, "Faltan " + menos.toString() + " vueltas siguiente objetivo.", Toast.LENGTH_SHORT).show()
            }

            true
        }

        //Imagen del trofeo 2 para el segundo objetivo
        if (cont == 20){
            trofeo2.setImageResource(R.drawable.trofeoo)
            Toast.makeText(this, "¡Felicidades, completaste!", Toast.LENGTH_SHORT).show()
        }

        //Imagen del trofeo 1 para el primer objetivo
        if (cont == 10){
            trofeo1.setImageResource(R.drawable.trofeooo)
            Toast.makeText(this, "¡Felicidades, completaste el primer objetivo!", Toast.LENGTH_SHORT).show()
        }

        else{
            trofeo1.setImageResource(R.drawable.empty_dice)
        }
    }

    //método para reiniciar el conteo
    fun reset(view: View) {
        cont = 0
        vueltas.text = "0"
        trofeoo.setImageResource(R.drawable.empty_dice)
        trofeooo.setImageResource(R.drawable.empty_dice)
    }

}
